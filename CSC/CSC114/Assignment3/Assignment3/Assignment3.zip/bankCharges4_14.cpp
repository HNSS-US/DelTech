// The MIT License (MIT)

// Copyright (c) 2019 James J. Warrington

//  Permission is hereby granted, free of charge, to any person obtaining a
//  copy of this software and associated documentation files (the "Software"),
//  to deal in the Software without restriction, including without limitation
//  the rights to use, copy, modify, merge, publish, distribute, sublicense,
//  and/or sell copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
//  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
//  DEALINGS IN THE SOFTWARE.

/* code */

// Bank Charges
// A bank charges $10 per month plus fees:
// $0.10 checks < 20
// $0.08 checks 20 - 39
// $0.06 checks 40 - 59
// $0.04 checks >= 60
// If balance < $400, fee of $15 added
// before any check fees are added.
// User inputs: 
//             current balance 
//             number of checks
// Input validation:
// Do not accept negative number of checks.
// Warn on negative opening balance.

#include <iostream> // cout, endl
#include <iomanip> // setfill
using namespace std; //saves std::

int main()
{
    double opnbalnce    = 0.00,  // input frm user
           endbalnce    = 0.00,  // calc value
           lowbalfee    = 15.00, // fee bal < 400.00
           chckfeechrgd = 0.0,   // calc value
           chckfeernge  = 0.0;   // variable for fee range chrgd

    int numchcks  = 0;           // number of chcks written 

    const double MINIMUM_BAL = 400.00, // min bal to avoid lowbalfee
                 MONTHLY_FEE = 10.00,  // mnthly maintaince fee
                 CHECK_FEE10 = 0.10,   // fee chcks wrttn < 20
                 CHECK_FEE08 = 0.08,   // fee chcks wrttn 20-39
                 CHECK_FEE06 = 0.06,   // fee chcks wrttn 40 - 59
                 CHECK_FEE04 = 0.04;   // fee chcks wrttn >= 60

    const int CHECK_LEVEL60  = 60,    // checks >= 60
              CHECK_LEVEL40  = 40,    // checks 40 - 59
              CHECK_LEVEL20  = 20;    // checks 20 - 39 
        

    char runcalc = 'N';               // do loop control

    string chckfeemsg1 = "Number of checks written was ",
           chckfeemsg2 = " gives a fee of $",
           minbalmsg  = "";

    cout << setfill('$') << setw(60) << ('$') << endl;

    // Request user input
    do // while (toupper(runcalc) != 'Y') 
    {
        cout << "Please enter the current balance in 00.00 format:\n";
        cin >> opnbalnce;

        if (opnbalnce < 0)
        {
            cout << setfill('!') << setw(60) << ('!') << endl;
            cout << "WARNING ACCOUNT IS OVERDRAWN CURENT BALANCE IS: " << endl;
            cout << setfill('!') << setw(60) << ('!') << endl;
        }

        do //while (numchcks < 0)
        {
            cout << "Please enter the number of checks written:\n";
            cin >> numchcks;

            if (numchcks < 0)
            {
                cout << setfill('?') << setw(60) << ('?') << endl;
                cout << "PLEASE RETRY, THE NUMBER OF CHECK CANNOT BE A NEGATIVE NUMBER" << endl;
            }  
        
        } while (numchcks < 0);

        cout << setfill('?') << setw(60) << ('?') << endl;
        cout << "You have entered the following values:\n";
        cout << "The current balance is :$" << fixed << setprecision(2) << opnbalnce << endl;
        cout << "The number of checks written is :" << numchcks << endl;
        cout << "Is this correct? y/n\n" ;
        cin >> runcalc;
        cout << setfill('?') << setw(60) << ('?') << endl;

        if (toupper(runcalc) == 'N')
        {
            cout << "Restarting...\n";
        }
        
    } while (toupper(runcalc) != 'Y');
    
    // Perform calculation for check writting fees
    // checks >= 60
    if (numchcks >= CHECK_LEVEL60)
    {
        chckfeechrgd = numchcks * CHECK_FEE04;
        chckfeernge  = CHECK_FEE04; 
    }
    // checks 40 - 59
    else if (numchcks >= CHECK_LEVEL40)
    {
        chckfeechrgd = numchcks * CHECK_FEE06;
        chckfeernge  = CHECK_FEE06;        
    }
    // checks 20 - 30
    else if (numchcks >= CHECK_LEVEL20)
    {
        chckfeechrgd = numchcks * CHECK_FEE08;
        chckfeernge  = CHECK_FEE08;
    }
    // checks < 20
    else
    {
        chckfeechrgd = numchcks * CHECK_FEE10;
        chckfeernge  = CHECK_FEE10;        
    }    

    
    cout << endl << endl << endl;
    cout << setfill('*') << setw(60) << ('*') << endl;
    
    //Preform calculation for ending balance
    if (opnbalnce < MINIMUM_BAL )
    {
        endbalnce = opnbalnce - chckfeechrgd- lowbalfee;
        cout << "Ending  balance on the account: $" << fixed << setprecision(2) << endbalnce << endl;
        cout << "This was calculated as follows:\n";    
        cout << "Opening balance on the account: $" << fixed << setprecision(2) << opnbalnce << endl;
        cout << "Check writting fee on " << numchcks << " checks at $" << fixed << setprecision(2) << chckfeernge ;
        cout << " per check is $" << fixed << setprecision(2) << chckfeechrgd << endl;
        cout << "Since open balance is below $" << MINIMUM_BAL;
        cout << " pay low balance fee of $" << fixed << setprecision(2) << lowbalfee << endl;
        cout << "Totaling $" << fixed << setprecision(2) << opnbalnce << " - $";
        cout << fixed << setprecision(2) << chckfeechrgd << fixed << setprecision(2);
        cout << " - $" << fixed << setprecision(2) << lowbalfee << " = $" << fixed << setprecision(2) << endbalnce << endl;
    }
    else
    {
        endbalnce = opnbalnce - chckfeechrgd;
        cout << "Ending  balance on the account: $" << endbalnce << endl;
        cout << "This was calculated as follows:\n";    
        cout << "Opening balance on the account: $" << opnbalnce << endl;
        cout << "Check writting fee on " << numchcks << " checks at $" << chckfeernge ;
        cout << " per check is $" << chckfeechrgd << endl;        
        cout << "Totaling $" << opnbalnce << " - $";
        cout << chckfeechrgd << " = $" << endbalnce << endl;
    }    

    cout << setfill('*') << setw(60) << ('*') << endl;
    return 0;
}
